//1

x = Number(prompt("Insira uma coordenada: "));
y = Number(prompt("Insira outra coordenada: "));
if(y>0){
    if(x>0){
    alert("Sua coordenada se encontra no quadrante I.");
    } else if(x<0){
        alert("Sua coordenada está no quadrante II.");
    };
}
if(y<0){
    if(x>0){
    alert("Sua coordenada está no quadrante IV.");
    } else if(x<0){
        alert("Sua coordenada está no quadrante III.");
    };
};
if(x==0 && y>0){
  alert("Sua coordenada está no eixo Y.");
};
if(y==0 && x>0){
    alert("Sua coordenada está no eixo X.");
}
if(x==0 && y==0){
    alert("Sua coordenada se encontra na origem.");
};

//2

n1 = parseInt(prompt("Insira um valor: "));
n2 = parseInt(prompt("Insira um valor: "));
n3 = parseInt(prompt("Insira um valor: "));
n4 = parseInt(prompt("Insira um valor: "));
n5 = parseInt(prompt("Insira um valor: "));
if(n1%2==0){    
    alert(n1 + " é par.");    
    console.log(n1 + " é par.");
};
if(n1%2==1){
    alert(n1 + " é impar.");    
    console.log(n1 + " é impar.");
};
if(n2%2==0){
    alert(n2 + " é par.");    
    console.log(n2 + " é par.");
};
if(n2%2==1){
    alert(n2 + " é impar.");    
    console.log(n2 + " é impar.");
};
if(n3%2==0){
    alert(n3 + " é par.");    
    console.log(n3 + " é par.");
};
if(n3%2==1){
    alert(n3 + " é impar.");    
    console.log(n3 + " é impar.")
};
if(n4%2==0){
    alert(n4 + " é par.");    
    console.log(n4 + " é par.");
};
if(n4%2==1){
    alert(n4 + " é impar.");    
    console.log(n4 + " é impar.")
};
if(n5%2==0){
    alert(n5 + " é par.");
    console.log(n5 + " é par.");
};
if(n5%2==1){
    alert(n5 + " é impar.");
    console.log(n5 + " é impar.")
};

//3

a1 = parseInt(prompt("Insira o nº de funcionários do andar: "));
a2 = parseInt(prompt("Insira o nº de funcionários do andar: "));
a3 = parseInt(prompt("Insira o nº de funcionários do andar: "));
if(a1>a2 && a1>a3){
    t = (a2*2)+(a3*4);
    alert("1º andar é o melhor posicionamento, total de minutos: " + t);
};
if(a2>a1 && a2>a3){
    t = (a1*2)+(a3*2);
    alert("2º andar é o melhor posicionamento, total de minutos: " + t);
};
if(a3>a2 && a3>a1){
    t = (a2*2)+(a1*4);
    alert("3º andar é o melhor posicionamento, total de minutos: " + t);
};
if(a1==a2 && a1>a3){
    t = (a3*2)+(a1*2);
    alert("2º é o melhor posicionamento, total de minutos: " + t);
};
if(a1==a2 && a1<a3){
    t = (a2*2)+(a1*4);
    alert("2º é o melhor posicionamento, total de minutos: " + t);
};
if(a3==a2 && a1>a3){
    t = (a2*2)+(a3*4);
    alert("1º é o melhor posicionamento, total de minutos: " + t);
};
if(a3==a2 && a1<a3){
    t = (a1*2)+(a3*2);
    alert("2º é o melhor posicionamento, total de minutos: " + t);
};
if(a3==a1 && a1>a2 || a3==a1 && a1<a2){
    t = (a3*2)+(a1*2);
    alert("2º é o melhor posicionamento, total de minutos: " + t);
};


