1)      //COMPLETO
var X,Y;
X=Number(prompt("Digite um numero"));
Y=Number(prompt("Digite outro numero"));
if(X>0 && Y>0){
    alert("O ponto esta no quadrante 1");}
if(X<0 && Y>0){
    alert("O ponto esta no quadrante 2");}
if(X<0 && Y<0){                                                                                           
    alert("O ponto esta no quadrante 3");}
if(X>0 && Y<0){
    alert("O ponto esta no quadrante 4");}

2)      //COMPLETO
var R,n1,n2,n3,n4,n5,R;
n1=Number(prompt("Digite um numero(n1)"));
R=n1%2
if(R==0){
    alert("Numero par");}
if(R!=0){
    alert("Numero impar");}
if(n1>0){
    alert("Numero positivo");
}else{
    alert("Numero negativo");}


n2=Number(prompt("Digite um numero(n2)"));
R=n2%2
if(R==0){
    alert("Numero par");}
if(R!=0){
    alert("Numero impar");}
if(n2>0){
    alert("Numero positivo");
}else{
    alert("Numero negativo");}

n3=Number(prompt("Digite um numero(n3)"));
R=n3%2
if(R==0){
    alert("Numero par");}
if(R!=0){
    alert("Numero impar");}
if(n3>0){
    alert("Numero positivo");
}else{
    alert("Numero negativo");}
                                

n4=Number(prompt("Digite um numero(n4)"));
R=n4%2
if(R==0){
    alert("Numero par");}
if(R!=0){
    alert("Numero impar");}
if(n4>0){
    alert("Numero positivo");
}else{
    alert("Numero negativo");}

n5=Number(prompt("Digite um numero(n5)"));
R=n5%2
if(R==0){
    alert("Numero par");}
if(R!=0){
    alert("Numero impar");}
if(n5>0){
    alert("Numero positivo");
}else{
    alert("Numero negativo");}


3)
var A1,A2,A3;
A1=Number(prompt("Digite o numero de pessoas que trabalham no 1º andar"));
A2=Number(prompt("Digite o numero de pessoas que trabalham no 2º andar"));
A3=Number(prompt("Digite o numero de pessoas que trabalham no 3º andar"));

































