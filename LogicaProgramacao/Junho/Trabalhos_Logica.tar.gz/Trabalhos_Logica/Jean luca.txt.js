//1
var x1,y1
var y1=parseFloat(prompt("digite o y do plano cartesiano"));
var x1=parseFloat(prompt("digite o x do plano cartesiano"));
if(y1>0 && x1>0){
alert("ele esta no Q1");
}
if(y1>0 && x1<0){
alert("ele esta no Q2");
}
if(y1<0 && x1<0){
alert("ele esta no Q3");
}
if(y1<0 && x1>0){
alert("ele esta no Q4");
}
if(y1==0 && x1==0){
alert("ele esta na origem");
}
if(y1>0 && x1==0){
alert("ele esta sobre o eixo x entre o Q1 e Q2");
}
if(y1<0 && x1==0){
alert("ele esta sobre o eixo x entre os Q3 e Q4");
}
if(y1==0 && x1>0){
alert("ele esta no eixo y entre o Q1 e Q4");
}
if(y1==0 && x1<0){
alert("ele esta no eixo y entre o Q2 e Q3");
}
//2
var p1,p2,p3,p4,p5,pa,ii,n1,po
pa=0
ii=0
n1=0
po=0
var p1=parseInt(prompt("digite um valor"));
var p2=parseInt(prompt("digite 2 valor"));
var p3=parseInt(prompt("digite 3 valor"));
var p4=parseInt(prompt("digite 4 valor"));
var p5=parseInt(prompt("digite 5 valor"));

if(p1>0 && p1%2==0){
po++
pa++
}
if(p1<0){
n1++
p1=p1*-1
if(p1%2==1){
ii++
}
}
if(p1<0){
n1++
if(p1%2==0){
pa++
}
}
if(p1>0 && p1%2==1){
po++
ii++
}
if(p2>0 && p2%2==0){
po++
pa++
}
if(p2<0){
n1++
p1=p1*-1
if(p1%2==1){
ii++
}
}
if(p2<0){
n1++
if(p2%2==0){
pa++
}

}
if(p2>0 && p2%2==1){
po++
ii++
}
if(p3>0 && p3%2==0){
po++
pa++
}
if(p3<0 ){
n1++
p1=p1*-1
if(p1%2==1){
ii++
}
}
if(p3<0){
n1++
if(p3%2==0){
pa++
}
}
if(p3>0 && p3%2==1){
po++
ii++
}
if(p4>0 && p4%2==0){
po++
pa++
}
if(p4<0){
n1++
p1=p1*-1
if(p1%2==1){
ii++
}
}
if(p4<0){
n1++
if(p4%2==0){
pa++
}
}
if(p4>0 && p4%2==1){
po++
ii++
}
if(p5>0 && p5%2==0){
po++
pa++
}
if(p5<0){
n1++
p1=p1*-1
if(p1%2==1){
ii++
}
}
if(p5<0){
n1++
if(p5%2==0){
pa++
}
}
if(p5>0 && p5%2==1){
po++
ii++
}

alert("positivos tem"+po+"pares tem"+pa+"negativos tem"+n1+"e impares tem"+ii);
//3
var A1,A2,A3,t1,t2,t3,tt
var A1=parseInt(prompt("digite o numero de pessoas do primeiro andar"));
var A2=parseInt(prompt("digite o numero de pessoas do segundo andar"));
var A3=parseInt(prompt("digite o numero de pessoas do terçeiro andar"));
t1=A1+A1
t2=A2+A2
t3=A3+A3
if(A1>A2 && A1>A3){
t3=A3+A3+A3+A3
if(t1>t3){
tt=t2+t3
alert("primeiro andar"+tt);
}
}
if(A3>A1 && A3>A2){
t1=A1+A1+A1+A1
if(t3>t1){
tt=t2+t1
alert("terçeiro andar"+tt);
}
}
if(A2>A1 && A2>A3){
tt=t1+t3
alert("segundo andar"+tt);
}

