0 = par / positivo / nulo

//1)
var x = parseFloat(prompt("digite o valor do eixo x"));
var y = parseFloat(prompt("digite o valor do eixo y"));
if(x > 0 && y > 0){
alert("está no primeiro quadrante");
}
if(x < 0 && y > 0){
alert("está no segundo quadrante");
}
if(x < 0 && y < 0){
alert("está no terceiro quadrante");
}
if(x > 0 && y < 0){
alert("está no quarto quadrante");
}
if(x == 0 && y == 0){
alert("esta na origem");
}

//2)

var a = parseInt(prompt("digite o valor 1"));
var b = parseInt(prompt("digite o valor 2"));
var c = parseInt(prompt("digite o valor 3"));
var d = parseInt(prompt("digite o valor 4"));
var e = parseInt(prompt("digite o valor 5"));
if(a > 0 && a%2 == 0){
alert("o valor 1 é par e positivo");
}
if(a < 0 && a%2 == 0){
alert("o valor 1 é par e negativo");
}
if(a > 0 && a%2 != 0){
alert("o valor 1 é impar e positivo");
}
if(a < 0 && a%2 != 0){
alert("o valor 1 é impar e negativo");
}
if(a == 0 && a%2 == 0){
alert("o valor 1 é par e positivo (nulo) (no caso é o 0)");
}
if(b > 0 && b%2 == 0){
alert("o valor 2 é par e positivo");
}
if(b < 0 && b%2 == 0){
alert("o valor 2 é par e negativo");
}
if(b > 0 && b%2 != 0){
alert("o valor 2 é impar e positivo");
}
if(b < 0 && b%2 != 0){
alert("o valor 2 é impar e negativo");
}
if(b == 0 && b%2 == 0){
alert("o valor 2 é par e positivo (nulo) (no caso é o 0)");
}
if(c > 0 && c%2 == 0){
alert("o valor 3 é par e positivo");
}
if(c < 0 && c%2 == 0){
alert("o valor 3 é par e negativo");
}
if(c > 0 && c%2 != 0){
alert("o valor 3 é impar e positivo");
}
if(c < 0 && c%2 != 0){
alert("o valor 3 é impar e negativo");
}
if(c == 0 && c%2 == 0){
alert("o valor 3 é par e positivo (nulo) (no caso é o 0)");
}
if(d > 0 && d%2 == 0){
alert("o valor 4 é par e positivo");
}
if(d < 0 && d%2 == 0){
alert("o valor 4 é par e negativo");
}
if(d > 0 && d%2 != 0){
alert("o valor 4 é impar e positivo");
}
if(d < 0 && d%2 != 0){
alert("o valor 4 é impar e negativo");
}
if(d == 0 && d%2 == 0){
alert("o valor 4 é par e positivo (nulo) (no caso é o 0)");
}
if(e > 0 && e%2 == 0){
alert("o valor 5 é par e positivo");
}
if(e < 0 && e%2 == 0){
alert("o valor 5 é par e negativo");
}
if(e > 0 && e%2 != 0){
alert("o valor 5 é impar e positivo");
}
if(e < 0 && e%2 != 0){
alert("o valor 5 é impar e negativo");
}
if(e == 0 && e%2 == 0){
alert("o valor 5 é par e positivo (nulo) (no caso é o 0)");
}


//3)
var A1 = parseFloat(prompt("digite o numero de pessoas que trabalham no primeiro andar"));
var A2 = parseFloat(prompt("digite o numero de pessoas que trabalham no segundo andar"));
var A3 = parseFloat(prompt("digite o numero de pessoas que trabalham no terceiro andar"));
var t1 = A1 + A2 + A3
if(A2 < A3){
var t2 = t1 + 20
alert("o tempo q sera preciso é de "+t2+" minutos");
}else{
alert("o tempo q sera preciso é de "+t1+" minutos");
}

//eu n tenho certeza se para outros casos de teste vão funcionar devidamente, mas de fato para os exemplos funcionaram okei
