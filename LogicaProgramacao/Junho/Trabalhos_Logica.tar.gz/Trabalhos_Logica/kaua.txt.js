
var x=parseFloat(prompt("informe o x"));
var y=parseFloat(prompt("informe o y"));

if(x==0 && y==0){
alert("esta na origem");
}

if(x>0 && y>0){
alert("esta no primeiro quadrante");
}

if(x<0 && y>0){
alert("esta no segundo quadrante");
}


if(x<0 && y<0){
alert("esta no terceiro quadrante");
}

if(x>0 && y<0){
alert("esta no quarto quadrante");
}


if(x==0 && y!=0){
alert("esta nobre o eixo Y");
}

if(x!=0 && y==0){
alert("esta nobre o eixo x");
}

var n1=parseInt(prompt("informe o valor do n1"));
var n2=parseInt(prompt("informe o valor do n2"));
var n3=parseInt(prompt("informe o valor do n3"));
var n4=parseInt(prompt("informe o valor do n4"));
var n5=parseInt(prompt("informe o valor do n5"));


var s1=n1%2;
var s2=n2%2;
var s3=n3%2;
var s4=n4%2;
var s5=n5%2;

var v=0;
var l=0;
var c=0;
var k=0;


if(s1==0){
v++
}

if(s2==0){
v++
}

if(s3==0){
v++
}

if(s4==0){
v++
}

if(s5==0){
v++
}

if(s1!=0){
l++
}

if(s2!=0){
l++
}

if(s3!=0){
l++
}

if(s4!=0){
l++
}

if(s5!=0){
l++
}

if(n1>0){
c++
}

if(n2>0){
c++
}

if(n3>0){
c++
}

if(n4>0){
c++
}

if(n5>0){
c++
}


if(n1<0){
k++
}

if(n2<0){
k++
}

if(n3<0){
k++
}

if(n4<0){
k++
}

if(n5<0){
k++
}
 if(n1==0 || n2==0 || n3==0 || n4==0 || n5==0){
alert("0 é par");
}
alert(v+" pares");
alert(l+" impares");
alert(c+" positivo");
alert(k+" negativo");




var a1=parseInt(prompt("informe o numero de pessoa do primeiro andar"));
var a2=parseInt(prompt("informe o numero de pessoa do segundo andar"));
var a3=parseInt(prompt("informe o numero de pessoa do terceiro andar"));

if(a2>a3){
alert((a1+a2+a3)+" MINUTOS");
}
if(a2<a3){
alert((a1+a3)*2+" MINUTOS")
}




















