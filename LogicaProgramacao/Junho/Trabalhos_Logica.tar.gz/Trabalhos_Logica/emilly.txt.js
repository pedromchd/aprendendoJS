//1
var x,y;
x=Number(prompt("insira o valor de x"));
y=Number(prompt("insira o valor de  x"));
if(x>0 && y<0){
alert("o ponto esta sobre o quadrante q4");
}
if(x>0 && y >0){
alert("o ponto esta sobre o quadrante q1");
}
if(x==0 && y==0){
alert(" o ponto esta passando na origem");
}
if(y<0 && x<0){
alert(" o ponto esta no quadrante q3");
}
if(y>0 && x<0){
alert ("o ponto esta no quadrante q2");
}

-----

//2

alert("o numero limite de numeros que voce pode apresentar é de \n -5 até 2 \n se voce nao mencionar algum desse valores,o numero não ira ser lido");
var n1,n2,n3,n4,n5;
n1=Number(prompt("insira o valor do primeiro numero"));
n2=Number(prompt("insira o valor do segundo numero"));
n3=Number(prompt("insira o valor do terceiro numero"));
n4=Number(prompt("insira o valor do quarto numero"));
n5=Number(prompt("insira o valor do quinto numero"));
alert("o numero limite de numeros que voce pode apresentar é de \n -5 até 2 \n se voce nao mencionar algum desse valores,o numero não ira ser lido");
 if(n2==0){
alert(" o n2 ele é par");
}
if(n2<0 && n2==-5){
alert("n2 é impar e negativo");
}
if(n2<0 && n2==-4){
alert("n2 é negativo e par");
}
if(n2<0 && n2==-3){
alert("n2 é negativo e impar");
}
if(n2<0 && n2==-2){
alert("n2 é negativo e par");
}
if(n2<0 && n2==-1){
alert("n2 é negativo e impar");
}
if(n2>0 && n2==1){
alert("n2 é positivo e impar");
}
if(n2>0 && n2==2){
alert("n2 é positivo e par");
}
else{
alert("n2 nao esta dentro da faixa entao \n nao podera ser lido");
}
 if(n1==0){
alert("ele é par");
}
if(n1<0 && n1==-5){
alert("n2 é impar e negativo");
}
if(n1<0 && n1==-4){
alert("n2 é negativo e par");
}
if(n1<0 && n1==-3){
alert("n2 é negativo e impar");
}
if(n1<0 && n1==-2){
alert("n2 é negativo e par");
}
if(n1<0 && n1==-1){
alert("n2 é negativo e impar");
}
if(n1>0 && n1==1){
alert("n2 é positivo e impar");
}
if(n1>0 && n1==2){
alert("n2 é positivo e par");
}
else{
alert("n1 nao esta dentro da faixa entao \n nao podera ser lido");
}
 if(n3==0){
alert("ele é par");
}
if(n3<0 && n3==-5){
alert("n2 é impar e negativo");
}
if(n3<0 && n3==-4){
alert("n2 é negativo e par");
}
if(n3<0 && n3==-3){
alert("n2 é negativo e impar");
}
if(n3<0 && n3==-2){
alert("n2 é negativo e par");
}
if(n3<0 && n3==-1){
alert("n2 é negativo e impar");
}
if(n3>0 && n3==1){
alert("n2 é positivo e impar");
}
if(n3>0 && n3==2){
alert("n2 é positivo e par");
}
else{
alert(" n3 nao esta dentro da faixa entao \n nao podera ser lido");
}
 if(n4==0){
alert("ele é par");
}
if(n4<0 && n4==-5){
alert("n2 é impar e negativo");
}
if(n4<0 && n4==-4){
alert("n2 é negativo e par");
}
if(n4<0 && n4==-3){
alert("n2 é negativo e impar");
}
if(n4<0 && n4==-2){
alert("n2 é negativo e par");
}
if(n4<0 && n4==-1){
alert("n2 é negativo e impar");
}
if(n4>0 && n4==1){
alert("n2 é positivo e impar");
}
if(n4>0 && n4==2){
alert("n2 é positivo e par");
}
else{
alert(" n4 nao esta dentro da faixa entao \n nao podera ser lido");
}
 if(n5==0){
alert("ele é par");
}
if(n5<0 && n5==-5){
alert("n2 é impar e negativo");
}
if(n5<0 && n5==-4){
alert("n2 é negativo e par");
}
if(n5<0 && n5==-3){
alert("n2 é negativo e impar");
}
if(n5<0 && n5==-2){
alert("n2 é negativo e par");
}
if(n5<0 && n5==-1){
alert("n2 é negativo e impar");
}
if(n5>0 && n5==1){
alert("n2 é positivo e impar");
}
if(n5>0 && n5==2){
alert("n2 é positivo e par");
}
else{
alert("n5 nao esta dentro da faixa entao \n nao podera ser lido");
}
------------

//3

var a1,a2,a3,m,and1,and,and2,and3,totaldp;
m=prompt("onde a maquina de café ira ficar?");
a1=Number(prompt("insira o numero de pessoas que trabalham no primeiro andar"));
a2=Number(prompt("insira o numero de pessoas que trabalham no segundo andar"));
a3=Number(prompt("insira o numero de pessoas que trabalham no terceiro andar"));
totaldp=(a1+a2+a3);
alert("o total de pessoas que trabalha no predio é de"+ totaldp);
alert("concluindo a máquina ficara melhor no segundo andar \n porque tanto pessoas do segundo quanto do primeiro andar vao levar menos tempo");

alert("cada pessoa do primeiro e segundo andar vao levar um minuto ate chegar a maquina,diferentemente se fosse em outro andar");










