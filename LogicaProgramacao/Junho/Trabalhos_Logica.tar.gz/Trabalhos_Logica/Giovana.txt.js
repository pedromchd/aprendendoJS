-----------------------------------------------------------------------------------
var x, y;//1
x= Number (prompt("Digite o valor de x."));
y= Number (prompt("DIgite o valor de y."));
if (x<0 && y<0) {
    alert ("O ponto está no quadrante 3.");
}
if (x>0 && y>0) {
    alert ("O ponto está no quadrante 1.");
}
if (x<0 && y>0) {
    alert ("O ponto está no quadrante 2.");
}
if (x>0 && y<0) {
    alert ("O ponto está no quadrante 4.");
}
if (x==0 && y>0 || y<0) {
    alert ("O ponto está sobre o eixo x.");
}
if (y==0 && x>0 || x<0) {
    alert ("O ponto está sobre o eixo y.");
}
if (x==0 && y==0) {
    alert ("O ponto está na origem.");
}
-----------------------------------------------------------------------------------
var n, n2, n3, n4, n5;//2
n= parseInt (prompt("Digite o valor do 1° número."));
n2= parseInt (prompt("Digite o valor do 2° número."));
n3= parseInt (prompt("Digite o valor do 3° número."));
n4= parseInt (prompt("Digite o valor do 4° número."));
n5= parseInt (prompt("Digite o valor do 5° número."));
if (n>0) {
alert ("O número " +n+ " é positivo.");
}
else {
    alert ("O número " + n+ " é negativo ");
}
if (n==0) {
alert ("O número " +n+ " é nulo.");
}
if (n%2==0) {
    alert ("e par.");
}
else {
    alert ("e ímpar.");
}
if (n2==0) {
alert ("O número " +n+ " é nulo.");
}
if (n2>0) {
alert ("O número " +n2+ " é positivo.");
}
else {
    alert ("O número " + n2+ " é negativo ");
}
if (n2%2==0) {
    alert ("e par.");
}
else {
    alert ("e ímpar.");
}
if (n3==0) {
alert ("O número " +n+ " é nulo.");
}
if (n3>0) {
alert ("O número " +n3+ " é positivo.");
}
else {
    alert ("O número " + n3+ " é negativo ");
}
if (n3%2==0) {
    alert ("e par.");
}
else {
    alert ("e ímpar.");
}
if (n4==0) {
alert ("O número " +n+ " é nulo.");
}
if (n4>0) {
alert ("O número " +n4+ " é positivo.");
}
else {
    alert ("O número " + n4+ " é negativo ");
}
if (n4%2==0) {
    alert ("e par.");
}
else {
    alert ("e ímpar.");
}
if (n5==0) {
alert ("O número " +n+ " é nulo.");
}
if (n5>0) {
alert ("O número " +n5+ " é positivo.");
}
else {
    alert ("O número " + n5+ " é negativo ");
}
if (n5%2==0) {
    alert ("e par.");
}
else {
    alert ("e ímpar.");
}
-----------------------------------------------------------------------------------


