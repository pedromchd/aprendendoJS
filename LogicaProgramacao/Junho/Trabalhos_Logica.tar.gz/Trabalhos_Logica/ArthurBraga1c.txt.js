/*EXERCICIO 1*/
var x,y
x=parseFloat(prompt("digite o valor de x"))
y=parseFloat(prompt("digite o valor de y"))
if(x==0 && y==0)
    alert("o ponto esta na origem")
else{
    if(y==0)
        alert("o ponto esta no eixo x")
    if(x==0)
        alert("o ponto esta no eixo y")
    if(x>0 && y>0)
        alert("o ponto esta no quadrante 1")
    if(x<0 && y>0)
        alert("o ponto esta no quadrante 2")
    if(x<0 && y<0)
        alert("o ponto esta no quadrante 3")
    if(x>0 && y<0)
        alert("o ponto esta no quadrante 4")
}

/*EXERCICIO 2*/
var n1,n2,n3,n4,n5,npo,ni,np,nn
n1=parseInt(prompt("digite o valor de n1"))
n2=parseInt(prompt("digite o valor de n2"))
n3=parseInt(prompt("digite o valor de n3"))
n4=parseInt(prompt("digite o valor de n4"))
n5=parseInt(prompt("digite o valor de n5"))
ni=Math.abs(n1%2+n2%2+n3%2+n4%2+n5%2)
np=5-ni
if(n1<0) 
    nn++
if(n2<0) 
    nn++
if(n3<0) 
    nn++
if(n4<0) 
    nn++
if(n5<0) 
    nn++
npo=5-nn
alert("Tem:"+np+" pares \nTem:"+ni+" impares \nTem:"+npo+" numeros positivos \nTem:"+nn+" numeros negativos")

/*EXERCICIO 3*/
var A1,A2,A3,nt1,nt2,nt3,mt
A1=parseInt(prompt("digite o numero de trabalhadores no andar 1"))
A2=parseInt(prompt("digite o numero de trabalhadores no andar 2"))
A3=parseInt(prompt("digite o numero de trabalhadores no andar 3"))  
nt1=A1*2+A3*2
nt2=A2*2+A3*4
nt3=A1*4+A2*2
mt=Math.min(nt1,nt2,nt3)
alert (mt)


