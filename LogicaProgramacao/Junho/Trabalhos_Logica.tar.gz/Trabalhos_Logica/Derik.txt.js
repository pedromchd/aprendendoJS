var vx,vy,q1,q2,q3,q4;
vx=parseFloat(prompt("digite um valor x"));
vy=parseFloat(prompt("digite um valor y"));
if(vx>=0 && vy>=0){
    alert("o valor é " +q1);
}
if(vx<=0 && vy>=0){
    alert("o valor é " +q2);
}
if(vx<=0 && vy<=0){
    alert("o valor é " +q3);
}
if(vx>=0 && vy<=0){
    alert("o valor é " +q4);
}

var v1,v2,v3,v4,v5;
v1=parseFloat(prompt("digite um valor"));
v2=parseFloat(prompt("digite um valor"));
v3=parseFloat(prompt("digite um valor"));
v4=parseFloat(prompt("digite um valor"));
v5=parseFloat(prompt("digite um valor"));
if(v1>0 && v2>0 && v3>0 && v4>0 && v5>0){
    alert("todos positivos");
}
if(v1<0 && v2>0 && v3>0 && v4>0 && v5>0){
    alert("4 positivos e 1 negativo");
}
if(v1<0 && v2<0 && v3>0 && v4>0 && v5>0){
    alert("3 positivos e 2 negativos");
}
if(v1<0 && v2<0 && v3<0 && v4>0 && v5>0){
    alert("2 positivos e 3 negativos");
}
if(v1<0 && v2<0 && v3<0 && v4<0 && v5>0){
    alert("1 positivo e 4 negativos");
}
if(v1<0 && v2<0 && v3<0 && v4<0 && v5<0){
    alert("todos positivos");
}

var a1,a2,a3,s;
a1=parseFloat(prompt("digite um numero de pessoas"));
a2=parseFloat(prompt("digite um numero de pessoas"));
a3=parseFloat(prompt("digite um numero de pessoas"));
//(0<=a1,a2,a3<=1000)//
s=(a1-a2%a3);
alert(s);
