var A1, A2, A3, A4, A5, A6, A7, A8, A9, M;
A1= parseInt(prompt("digite o primeiro numero na primeira linha"));
if (A1==10) {
alert("o primeiro numero é dez");
}
A2= parseInt(prompt("digite o segundo numero na primeira linha"));
if (A2==10) {
alert("o segundo numero é dez");
}
A3= parseInt(prompt("digite o terceiro numero na primeira linha"));
if (A3==10) {
alert("o terceiro é dez")
}
A4= parseInt(prompt("digite o quarto numero na segunda linha"));
if (A4==10) {
alert("o quarto numero é dez");
}
A5= parseInt(prompt("digite o quinto numero na segunda linha"));
if (A5==10) {
alert("o quinto numero é dez;");
}
A6= parseInt(prompt("digite o sexto numero na segunda linha"));
if (A6==10) {
alert("o sexto numero é dez");
}
A7= parseInt(prompt("digite o setimo numero na terceira linha"));
if (A7==10) {
alert("o setimo numero é dez");
}
A8= parseInt(prompt("digite o oitavo numero na terceira linha"));
if (A8==10) {
alert("o oitavo numero é dez");
}
A9= parseInt(prompt("digite o nono numero na terceira linha"));
if (A9==10) {
alert("o nono numero é dez");
}
if (M==30) {
Alert("o cubo é magico parabens");
}
if (M>=30) {
Alert ("o cubo é quase magico");
}
if (M<30) {
Alert("o cubo nao é magico");
}
---------------------------------------------------------------------------------------------------------------------
                            //QUESTÃO 2
var valor;
n= parseInt(prompt("digite um numero de 1 a 5"));
switch (n) {
   case 1:
     valor="valor negativo";
     break;
   case 2:
     valor="valor par";
     break;
   case 3:
     valor="valor impar";
     break;
  case 4:
     valor="valor positivo";
     break;
  case 5:
     valor="valor impar";
}
     alert(n);
-------------------------------------------------------------------------------------------------------------------------------------------------
                                         //QUESTÃO 3
var A, B, C;
A= parseInt(prompt("insira aqui o numero exato de xicaras de farinha de trigo"));
B= parseInt(promot("insira aqui o numero exato de ovos"));
C= parseInt(prompt("insira aqui o numero de colheres de sopa de leite"));
if (A==2) {
alert ("o numero de xicaras de leite é" + A);
}
if (B==3) {
alert ("o numero de ovos é" + B);
}
if (C==5) {
alert ("o numero de colheres de sopa de leite é:" + C);
}
alert("joao vai fazer 3 bolos!!!");


t























































