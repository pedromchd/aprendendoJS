//1
var x,y,q
x=Number(prompt("diga X"))
y=Number(prompt("diga Y"))
if (x>0 && y>0)
q="Quadrante 1"
if (x<0 && y<0)
q="Quadrante 3"
if (x>0 && y<0)
q="Quadrante 4"
if (x<0 && y>0)
q="Quadrante 2"
if (x==0)
q="O ponto está sobre o eixo Y"
if (y==0)
q="O ponto está sobre o eixo X"
if (x==0 && y==0)
q="O ponto está sobre a origem"
alert(q)

//2
var n1,n2,n3,n4,n5,qp,qn,qp,qi
//qpo,qne,qp,qi = quantidade de: positivos, negativos, pares, ímpares
n1=parseInt(prompt("diga int 1"))
n2=parseInt(prompt("diga int 2"))
n3=parseInt(prompt("diga int 3"))
n4=parseInt(prompt("diga int 4"))
n5=parseInt(prompt("diga int 5"))
qp=0
qi=0
qpo=0
qne=0
if (n1>0)
++qpo
if (n1<0)
++qne
if (n1%2==0)
++qp
if (n1%2!==0)
++qi

if (n2>0)
++qpo
if (n2<0)
++qne
if (n2%2==0)
++qp
if (n2%2!==0)
++qi

if (n3>0)
++qpo
if (n3<0)
++qne
if (n3%2==0)
++qp
if (n3%2!==0)
++qi

if (n4>0)
++qpo
if (n4<0)
++qne
if (n4%2==0)
++qp
if (n4%2!==0)
++qi

if (n5>0)
++qpo
if (n5<0)
++qne
if (n5%2==0)
++qp
if (n5%2!==0)
++qi

alert("a quantia de números pares foi: "+qp+", a de ímpares: "+qi+", a de positivos foi: "+qpo+" e a de negativos foi :"+qne)

//3
var a1,a2,a3,mins
a1=parseInt(prompt("Diga o número de proletas do andar 1"))
a2=parseInt(prompt("Diga o número de proletas do andar 2"))
a3=parseInt(prompt("Diga o número de proletas do andar 3"))
if (a1>=0 && a1<=1000 && a2>=0 && a2<=1000 && a3>=0 && a3<=1000) {
    if (a1>a2 && a1>a3)
    mins=a2*2 + a3*4
    if (a3>a2 && a3>a1)
    mins=a2*2 + a1*4
    if (a2>a1 && a2>a3)
    mins=a1*2 + a3*2
    if (a1==a3 || a1==a2 || a2==a3)
    mins=a1*2 + a3*2
    if (a1==a2 || a3==a2)
    mins=a1*2 + a3*2
   alert(mins)
} else
alert("Dados inválidos")







