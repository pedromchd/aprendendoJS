//Coordenadas de um ponto em um plano cartesiano
var x, y;
x=Number(prompt("Insira o x: "));
y=Number(prompt("Insira o y: "));
if(x>0 && y>0){
    alert("Este ponto pertence ao quadrante 1!");
}
if(x<0 && y>0){
    alert("Este ponto pertence ao quadrante 2!");
}
if(x<0 && y<0){
    alert("Este ponto pertence ao quadrante 3!");
}
if(x>0 && y<0){
    alert("Este ponto pertence ao quadrante 4!");
}
if(x==0 && (y>0 || y<0)){
    alert("Este ponto está sobre o eixo y!");
}
if(y==0 && (x>0 || x<0)){
    alert("Este ponto está sobre o eixo x!");
}
if(x==0 && y==0){
    alert("Este ponto está sobre a origem!");
}

//Determinar valores 
var n1, n2, n3, n4, n5;
n1=parseInt(prompt("Insira um número: "));
n2=parseInt(prompt("Insira outro número: "));
n3=parseInt(prompt("Insira outro número: "));
n4=parseInt(prompt("Insira outro número: "));
n5=parseInt(prompt("Insira um último número: "));
if(n1%2==0 ||n1==0){
    alert(n1+ " é par!");
}else{
    alert(n1+ " é ímpar!");
}
if(n1>0){
    alert(n1+ " é positivo!");
}else if(n1==0){
    alert(n1+ " é nulo!");
}else{
    alert(n1+ " é negativo!");
}
if(n2%2==0 || n2==0){
    alert(n2+ " é par!");
}else{
    alert(n2+ " é ímpar!");
}
if(n2>0){
    alert(n2+ " é positivo!");
}else if(n2==0){
    alert(n2+ " é nulo!");
}else{
    alert(n2+ " é negativo!");
}
if(n3%2==0 || n3==0){
    alert(n3+ " é par!");
}else{
    alert(n3+ " é ímpar!");
}
if(n3>0){
    alert(n3+ " é positivo!");
}else if(n3==0){
    alert(n3+ " é nulo!");
}else{
    alert(n3+ " é negativo!");
}
if(n4%2==0 || n4==0){
    alert(n4+ " é par!");
}else{
    alert(n4+ " é ímpar!");
}
if(n4>0){
    alert(n4+ " é positivo!");
}else if(n4==0){
    alert(n4+ " é nulo!");
}else{
    alert(n4+ " é negativo!");
}if(n5%2==0 || n5==0){
    alert(n5+ " é par!");
}else{
    alert(n5+ " é ímpar!");
}
if(n5>0){
    alert(n5+ " é positivo!");
}else if(n5==0){
    alert(n5+ " é nulo!");
}else{
    alert(n5+ " é negativo!");
}

//Empresa do café
var a1, a2, a3;
a1=parseInt(prompt("Insira o número de pessoas que trabalham no primeiro andar: "));
a2=parseInt(prompt("Insira o número de pessoas que trabalham no segundo andar: "));
a3=parseInt(prompt("Insira o número de pessoas que trabalham no terceiro andar: "));
mt=(a1*2)+(a2*2);
alert(mt);

