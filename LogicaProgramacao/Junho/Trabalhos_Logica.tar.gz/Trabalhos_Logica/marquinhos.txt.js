//pontos no grafico cartesiano//

var X, Y;

X = parseFloat(prompt("Insira o valor de X:"));
Y = parseFloat(prompt("Insira o valor de Y:"));
    
    if (X == 0 && Y > 0 || X == 0 && Y < 0) {
        alert("O ponto está sobre o eixo Y.");
    }
    if (X > 0 && Y == 0 || X < 0 && Y == 0) {
        alert("O ponto está sobre o eixo X.");
    }
    if (X == 0 && Y == 0) {
        alert("O ponto está na origem.");
    }
    else {
    if (X > 0 && Y > 0) {
        alert("O ponto está no quadrante 1.");
    }
    if (X < 0 && Y > 0) {
        alert("O ponto está no quadrante 2.");
    }
    if (X < 0 && Y < 0) {
        alert("O ponto está no quadrante 3.");
    }
    if (X > 0 && Y < 0) {
        alert("O ponto está no quadrante 4.");
    } }
    
//valores inteiros pares, impares, positivos e negativos//

var N1, N2, N3, N4, N5;

N1 = parseInt(prompt("Insira o primeiro número."));
N2 = parseInt(prompt("Insira o segundo número."));
N3 = parseInt(prompt("Insira o terceiro número."));
N4 = parseInt(prompt("Insira o quarto número."));
N5 = parseInt(prompt("Insira o quinto número."));
  
    alert("Os números pares são:");
    if(N1%2 == 0) {
        alert(N1);
}
    if(N2%2 == 0) {
        alert(N2);
}
    if(N3%2 == 0) {
        alert(N3);
}
    if(N4%2 == 0) {
        alert(N4);
}
    if(N5%2 == 0) {
        alert(N5);
}
    alert("Os número ímpares são:");
    if(N1%2 != 0) {
        alert(N1);
} 
    if(N2%2 != 0) {
        alert(N2);
} 
    if(N3%2 != 0) {
        alert(N3);
} 
    if(N4%2 != 0) {
        alert(N4);
} 
    if(N5%2 != 0) {
        alert(N5);
} 
    alert("Os números negativos são:");
    if (N1 < 0) {
        alert(N1);
}
    if (N2 < 0) {
        alert(N2);
}
    if (N3 < 0) {
        alert(N3);
}
    if (N4 < 0) {
        alert(N4);
}
    if (N5 < 0) {
        alert(N5);
}
    alert("Os números positivos são:");
    if (N1 > 0) {
        alert(N1); 
}
    if (N2 > 0) {
        alert(N2); 
}
    if (N3 > 0) {
        alert(N3); 
}
    if (N4 > 0) {
        alert(N4); 
}
    if (N5 > 0) {
        alert(N5); 
}

//máquina de expresso//
    
var A1, A2, A3;
    
A1 = parseInt(prompt("Insira o número de pessoas que trabalham no primeiro andar:"));
A2 = parseInt(prompt("Insira o número de pessoas que trabalham no segundo andar:"));
A3 = parseInt(prompt("Insira o número de pessoas que trabalham no terceiro andar:"));

   if(Math.max(A1,A2,A3 ) == A1 && Math.min(A1,A2,A3) == A2) {
     K1 = 2
}
    if(Math.max(A1,A2,A3) == A1 && Math.min(A1,A2,A3) == A3) {
     K1 = 2
}
    if(Math.max(A1,A2,A3) == A2 && Math.min(A1,A2,A3) == A1) {
     K1 = 2
}
    if(Math.max(A1,A2,A3) == A2 && Math.min(A1,A2,A3) == A3) {
     K1 = 1
}
    if(Math.max(A1,A2,A3) == A3 && Math.min(A1,A2,A3) == A2) {
     K1 = 1
}
    if(Math.max(A1,A2,A3) == A3 && Math.min(A1,A2,A3) == A1) {
     K1 = 1
}
    if (Math.min(A1,A2,A3) == A1 && Math.max(A1,A2,A3) == A2) {
     K2 = 1
}
    if(Math.min(A1,A2,A3) == A1 && Math.max(A1,A2,A3) == A3) {
     K2 = 1
}
    if(Math.min(A1,A2,A3) == A2 && Math.max(A1,A2,A3) == A1) {
     K2 = 1
}
    if(Math.min(A1,A2,A3) == A2 && Math.max(A1,A2,A3) == A3) {
     K2 = 2
}
    if(Math.min(A1,A2,A3) == A3 && Math.max(A1,A2,A3) == A2) {
     K2 = 2
}
    if(Math.min(A1,A2,A3) == A3 && Math.max(A1,A2,A3) == A1) {
     K2 = 2
}
X = A1 + A2 + A3
Y = X - Math.max(A1, A2, A3) - Math.min(A1, A2, A3)
MT = (Math.max(A1, A2, A3) * 0) + (Math.min(A1, A2, A3) * K2) + Y * K1;
alert(MT)
