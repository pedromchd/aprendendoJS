//1
var x = Number(prompt('Digite a cordenada x'));
var y = Number(prompt('Digite a cordenada y'));

if (x == 0 && y == 0) {
    alert('Está na origem');
}

if (x > 0 && y > 0) {
    alert('Está no quadrante 1');
}

if (x < 0 && y < 0) {
    alert('Está no quadrante 3');
}

if (x > 0 && y < 0) {
    alert('Está no quadrante 4');
}

if (x < 0 && y > 0) {
    alert('Está no quadrante 2');
}

//2
var n1 = parseInt(prompt('Digite o número 1'));
var n2 = parseInt(prompt('Digite o número 2'));
var n3 = parseInt(prompt('Digite o número 3'));
var n4 = parseInt(prompt('Digite o número 4'));
var n5 = parseInt(prompt('Digite o número 5'));

//Pares
if (n1 % 2 == 0) {
    alert('n1 : ' +n1+ ' ,é Par');
}

if (n2 % 2 == 0) {
    alert('n2 : ' +n2+ ' ,é Par');
}

if (n3 % 2 == 0) {
    alert('n3 : ' +n3+ ' ,é Par');
}

if (n4 % 2 == 0) {
    alert('n4 : ' +n4+ ' ,é Par');
}

if (n5 % 2 == 0) {
    alert('n5 : ' +n5+ ' ,é Par');
}

//Impares
if (n1 % 2 == 1 || n1 % 2 == -1) {
    alert('n1 : ' +n1+ ' ,é Impar');
}

if (n2 % 2 == 1 || n2 % 2 == -1) {
    alert('n2 : ' +n2+ ' ,é Impar');
}

if (n3 % 2 == 1 || n3 % 2 == -1) {
    alert('n3 : ' +n3+ ' ,é Impar');
}

if (n4 % 2 == 1 || n4 % 2 == -1) {
    alert('n4 : ' +n4+ ' ,é Impar');
}

if (n5 % 2 == 1 || n5 % 2 == -1) {
    alert('n5 : ' +n5+ ' ,é Impar');
}

//Positivos
if (n1 > 0) {
    alert('n1 : ' +n1+ ' ,é Positivo');
}

if (n2 > 0) {
    alert('n2 : ' +n2+ ' ,é Positivo');
}

if (n3 > 0) {
    alert('n3 : ' +n3+ ' ,é Positivo');
}

if (n4 > 0) {
    alert('n4 : ' +n4+ ' ,é Positivo');
}

if (n5 > 0) {
    alert('n5 : ' +n5+ ' ,é Positivo');
}

//Negativos
if (n1 < 0) {
    alert('n1 : ' +n1+ ' ,é Negativo');
} 

if (n2 < 0) {
    alert('n2 : ' +n2+ ' ,é Negativo');
}

if (n3 < 0) {
    alert('n3 : ' +n3+ ' ,é Negativo');
}

if (n4 < 0) {
    alert('n4 : ' +n4+ ' ,é Negativo');
}

if (n5 < 0) {
    alert('n5 : ' +n5+ ' ,é Negativo');
}

//3

var a1 = Number(prompt('Digite a1'));
var a2 = Number(prompt('Digite a2'));
var a3 = Number(prompt('Digite a3'));

if (a1 >= 0 && a1 <= 1000){
    
    if (a2 >= 0 && a2 <= 1000){
        
        if (a3 >= 0 && a3 <= 1000) {
            var t = (a1 * 2) + (a3 * 2);
            alert(t);
        } 
    }
}