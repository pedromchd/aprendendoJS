//exercicio 1

var x, y;
x = parseInt(prompt("Entre com o eixo x: "));
y = parseInt(prompt("Entre com o eixo y: "));

if(x > 0 && y > 0){
    alert("Q1");
}
if(x < 0 && y > 0){
    alert("Q2");
}
if(x < 0 && y < 0){
    alert("Q3");
}
if(x > 0 && y < 0){
    alert("Q4");
}
if(x == 0 && y == 0){
    alert("Origem");
}

//exercicio 2

var n1, n2, n3, n4, n5;
n1 = parseInt(prompt("Entre com o primeiro número: "));
n2 = parseInt(prompt("Entre com o segundo número: "));
n3 = parseInt(prompt("Entre com o terceiro número: "));
n4 = parseInt(prompt("Entre com o quarto número: "));
n5 = parseInt(prompt("Entre com o quinto número: "));

if(n1%2 == 0){
    alert("O 1º é par.");
}else{
    alert("O 1º é impar.");
}
if(n1 > 0){
    alert("O 1º é positivo.");
}else{
    alert("O 1º é negativo.");
}
if(n1 == 0){
    alert("nulo");
}

if(n2%2 == 0){
    alert("O 2º é par.");
}else{
    alert("O 2º é impar.");
}
if(n2 > 0){
    alert("O 2º é positivo.");
}else{
    alert("O 2º é negativo.");
}
if(n2 == 0){
    alert("nulo");
}

if(n3%2 == 0){
    alert("O 3º é par.");
}else{
    alert("O 3º é impar.");
}
if(n3 > 0){
    alert("O 3º é positivo.");
}else{
    alert("O 3º é negativo.");
}
if(n3 == 0){
    alert("nulo");
}

if(n4%2 == 0){
    alert("O 4º é par.");
}else{
    alert("O 4º é impar.");
}
if(n4 > 0){
    alert("O 4º é positivo.");
}else{
    alert("O 4º é negativo.");
}
if(n4 == 0){
    alert("nulo");
}

if(n5%2 == 0){
    alert("O 5º é par.");
}else{
    alert("O 5º é impar.");
}
if(n5 > 0){
    alert("O 5º é positivo.");
}else{
    alert("O 5º é negativo.");
}
if(n5 == 0){
    alert("nulo");
}

//exercicio 3

var a1, a2, a3;

a1 = parseInt(prompt("Entre com o primeiro andar: "));
a2 = parseInt(prompt("Entre com o segundo andar: "));
a3 = parseInt(prompt("Entre com o terceiro andar: "));


if(a1 > a2 && a1 > a3){
    p = (a2*2) + (a3*4);
    alert(p);
}
if(a1 < a2 && a2 > a3){
    p = (a1*2) + (a3*2);
    alert(p);
}
if(a1 < a3 && a2 < a3){
    p = (a1*4) + (a2*2);
    alert(p);
}

