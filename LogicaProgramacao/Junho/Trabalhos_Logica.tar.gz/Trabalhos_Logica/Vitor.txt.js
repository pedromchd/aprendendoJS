var x,y;                                                   //Exercício 1
var x=Number(prompt("Digite a localização no eixo X do ponto."));
var y=Number(prompt("Digite a localização no eixo Y do ponto."));
if (x==0 && y==0) {
    alert("O ponto está sobre a origem.");
}
if (x==0 && y!=0) {
    alert("O ponto está sobre o eixo Y.");
}
if (x!=0 && y==0) {
    alert("O ponto está sobre o eixo X.");
}
if (x>0 && y>0) {
    alert("O ponto está localizado no quadrante 1.");
}
if (x<0 && y>0) {
    alert("O ponto está localizado no quadrante 2.");
}
if (x<0 && y<0) {
    alert("O ponto está localizado no quadrante 3.");
}
if (x>0 && y<0) {
    alert("O ponto está localizado no quadrante 4.");
}

var v1,v2,v3,v4,v5;                                        //Exercício 2
var v1=parseInt(prompt("Digite o primeiro valor."));
var v2=parseInt(prompt("Digite o segundo valor."));
var v3=parseInt(prompt("Digite o terceiro valor."));
var v4=parseInt(prompt("Digite o quarto valor."));
var v5=parseInt(prompt("Digite o último valor."));
if (v1%2==0) {
    alert(v1 + " é par.");
} else {
    alert(v1 + " é ímpar.");
}
if (v1<0) {
    alert(v1 + " é negativo.");
}
if (v1>0) {
    alert(v1 + " é positivo.");
}
if (v2%2==0) {
    alert(v2 + " é par.");
} else {
    alert(v2 + " é ímpar.");
}
if (v2<0) {
    alert(v2 + " é negativo.");
}
if (v2>0) {
    alert(v2 + " é positivo.");
}
if (v3%2==0) {
    alert(v3 + " é par.");
} else {
    alert(v3 + " é ímpar.");
}
if (v3<0) {
    alert(v3 + " é negativo.");
}
if (v3>0) {
    alert(v3 + " é positivo.");
}
if (v4%2==0) {
    alert(v4 + " é par.");
} else {
    alert(v4 + " é ímpar.");
}
if (v4<0) {
    alert(v4 + " é negativo.");
}
if (v4>0) {
    alert(v4 + " é positivo.");
}
if (v5%2==0) {
    alert(v5 + " é par.");
} else {
    alert(v5 + " é ímpar.");
}
if (v5<0) {
    alert(v5 + " é negativo.");
}
if (v5>0) {
    alert(v5 + " é positivo.");
}

var a1,a2,a3;                                              //Exercício 3
var a1=parseInt(prompt("Digite o número de pessoas que trabalham no 1º andar."));
var a2=parseInt(prompt("Digite o número de pessoas que trabalham no 2º andar."));
var a3=parseInt(prompt("Digite o número de pessoas que trabalham no 3º andar."));
if (a1>a2 && a1>a3) {
    alert(a2*2+a3+4);
}
if (a2>a1 && a2>a3) {
    alert(a1*2+a3*2);
}
if (a3>a1 && a3>a2) {
    alert(a1*4+a2*2);
}
