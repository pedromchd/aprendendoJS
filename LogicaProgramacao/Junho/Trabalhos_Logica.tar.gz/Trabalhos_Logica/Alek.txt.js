//1

var X = parseFloat(prompt("insira o valor de X")); //1
var Y = parseFloat(prompt("insira o valor de Y")); //2
  if(X==0 && Y==0) {
alert("O ponto está na origem");
} else if (X > 0 && Y > 0) {
alert("O ponto está no primeiro quadrante");
} else if (X < 0 && Y < 0) {
alert("O ponto está no terceiro quadrante");
} else if (X > 0 && Y < 0) {
alert("O ponto está no quarto quadrante");
} else if (X < 0 && Y > 0) {
alert("O ponto está no segundo quadrante");
}

//2

var N1 = parseFloat(prompt("insira o primeiro valor"));
var N2 = parseFloat(prompt("insira o segundo valor" ));
var N3 = parseFloat(prompt("insira o terceiro valor"));
var N4 = parseFloat(prompt("insira o quarto valor"  ));
var N5 = parseFloat(prompt("insira o quinto valor"  )); 
 if(N1%2==0 && N2%2==0 && N3%2==0 && N4%2==0 && N5%2==0) {
alert("5 números são pares");
}
if (N1%2!=0 || N2%2==0 || N3%2!=0 || N4%2==0 || N5!=0) {
alert("3 valores são negativos e 2 são pares");
}
if (N1 < 0 || N2 > 0 || N3 < 0 || N4 > 0 || N5 < 0) {
alert("3 valores são negativos e 2 positivos");
}
if (N1 > 0 && N2 < 0 && N3 > 0 && N4 < 0 && N5 > 0) {
alert("3 valores são positivo e 2 negativos");
}
 if(N1%2!=0 && N2%2==0 && N3%2!=0 && N4%2==0 && N5%2!=0) {
alert("2 valores são ímpar e 3 são pares");
}
 if(N2%1==0 && N2%2!=0 && N3%2==0 && N4%2!=0 && N5%2==0) {
alert("3 valores são pares e 2 são ímpar");
}



//3
var A1 = parseFloat(prompt("insira o número de funcionários do primeiro andar"));
var A2 = parseFloat(prompt("insira o número de funcionários do segundo andar" ));
var A3 = parseFloat(prompt("insira o número de funcionários do terceiro andar"));
var AA1 = (A1*3)+A2+A3;
var AA2 = A2 + A1 + A3;
var AA3 = A1 + A2 + (A3*2);
 if(A1 < A2 && A1 < A3 && A2 < A3) {
alert("Os minutos a serem gasto no melhor posicionamento serão: "+AA1);
} else if (A1 < A2 && A1 < A3 && A2 > A3) {
alert("Os minutos a serem gasto no melhor posicionamento serão: "+AA2);
} else {
alert("Os minutos a serem gastos no melhor posicionamento serão: "+AA3);
}









