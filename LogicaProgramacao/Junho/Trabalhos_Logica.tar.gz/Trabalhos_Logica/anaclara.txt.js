//Trabalho de Lógica de Programação
//Nome: Ana Clara Cardozo
//Matrícula: 11030308

//1)
var x,y;
x=Number(prompt("Valor de X:"));
y=Number(prompt("Valor de Y:"));
if(x>0 && y>0){
    alert("Ponto pertencente ao Q1 (primeiro quadrante)");
}else if(x<0 && y>0){
    alert("Ponto pertencente ao Q2 (segundo quadrante)");
}else if(x<0 && y<0){
    alert("Ponto pertencente ao Q3 (terceiro quadrante)");
}else if(x>0 && y<0){
    alert("Ponto pertencente ao Q4 (quarto quadrante)");
}else if(x==0 && y!=0){
    alert("Ponto localizado no eixo Y");
}else if(x!=0 && y==0){
    alert("Ponto localizado no eixo X");
}else{
    alert("Ponto localizado na origem");
}

//2)
var a,b,c,d,e,cont_p,cont_i,cont_pos,cont_n;
a=Number(prompt("Valor de a:"));
b=Number(prompt("Valor de b:"));
c=Number(prompt("Valor de c:"));
d=Number(prompt("Valor de d:"));
e=Number(prompt("Valor de e:"));
cont_p=0;
cont_i=0;
cont_pos=0;
cont_n=0;
if(a%2==0){
    cont_p+=1;
}
if(b%2==0){
    cont_p+=1;
}
if(c%2==0){
    cont_p+=1;
}
if(d%2==0){
    cont_p+=1;
}
if(e%2==0){
    cont_p+=1;
}
if(Math.abs(a)%2==1){
    cont_i+=1;
}
if(Math.abs(b)%2==1){
    cont_i+=1;
}
if(Math.abs(c)%2==1){
    cont_i+=1;
}
if(Math.abs(d)%2==1){
    cont_i+=1;
}
if(Math.abs(e)%2==1){
    cont_i+=1;
}
if(a>0){
    cont_pos+=1;
}
if(b>0){
    cont_pos+=1;
}
if(c>0){
    cont_pos+=1;
}
if(d>0){
    cont_pos+=1;
}
if(e>0){
    cont_pos+=1;
}
if(a<0){
    cont_n+=1;
}
if(b<0){
    cont_n+=1;
}
if(c<0){
    cont_n+=1;
}
if(d<0){
    cont_n+=1;
}
if(e<0){
    cont_n+=1;
}
alert("Há "+cont_p+" valores pares, "+cont_i+" valores ímpares, "+cont_pos+" valores positivos e "+cont_n+" valores negativos");

//3)
var a1,a2,a3,t;
a1=Number(prompt("Quantidade de Pessoas no andar 1:"));
a2=Number(prompt("Quantidade de Pessoas no andar 2:"));
a3=Number(prompt("Quantidade de Pessoas no andar 3:"));
if(a2>a1 || a2>a3){
    t=a1+a2+a3;
}else if(a3>a1 || a3>a1){
    t=a1*2+a2+a3;
}else if(a1>a2 || a1>a3){
    t=a1+a2+a3*2;
}
alert(t);

