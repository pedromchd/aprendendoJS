//Exercício 1//

var x,y;
x=Number(prompt("Digite um número para o ponto x"));
y=Number(prompt("Digite um número para o ponto y"));
if(x==0 && y==0){
alert("O ponto está sobre a origem do plano cartesiano");
}
if(x==0 && y!=0){
alert("O ponto está sobre o eixo y");
}
if(x!=0 && y==0){
alert("O ponto está sobre o eixo x");
}
if(x > 0 && y > 0){
alert("O ponto pertence ao primeiro quadrante");
}
if(x < 0 && y > 0){
alert("O ponto pertence ao segundo quadrante");
}
if(x < 0 && y < 0){
alert("O ponto pertence ao terceiro quadrante");
}
if(x > 0 && y < 0){
alert("O ponto pertence ao quarto quadrante");
}

//Exercício 2//

var n1,n2,n3,n4,n5;
n1=parseInt(prompt("Digite um número"));
n2=parseInt(prompt("Digite um número"));
n3=parseInt(prompt("Digite um número"));
n4=parseInt(prompt("Digite um número"));
n5=parseInt(prompt("Digite um número"));
if(n1 > 0 && n1%2==0){
alert("O número: " + n1 + " é positivo e par");
}
if(n1 > 0 && n1%2!=0){
alert("O número: " + n1 + " é positivo e ímpar");
}
if(n1 < 0 && n1%2==0){
alert("O número: " + n1 + " é negativo e par");
}
if(n1 < 0 && n1%2!=0){
alert("O número: " + n1 + " é negativo e ímpar");
}
if(n1==0){
alert("O número: " + n1 + " é par");
}
if(n2 > 0 && n2%2==0){
alert("O número: " + n2 + " é positivo e par");
}
if(n2 > 0 && n2%2!=0){
alert("O número: " + n2 + " é positivo e ímpar");
}
if(n2 < 0 && n2%2==0){
alert("O número: " + n2 + " é negativo e par");
}
if(n2 < 0 && n2%2!=0){
alert("O número: " + n2 + " é negativo e ímpar");
}
if(n2==0){
alert("O número: " + n2 + " é par");
}
if(n3 > 0 && n3%2==0){
alert("O número: " + n3 + " é positivo e par");
}
if(n3 > 0 && n3%2!=0){
alert("O número: " + n3 + " é positivo e ímpar");
}
if(n3 < 0 && n3%2==0){
alert("O número: " + n3 + " é negativo e par");
}
if(n3 < 0 && n3%2!=0){
alert("O número: " + n3 + " é negativo e ímpar");
}
if(n3==0){
alert("O número: " + n3 + " é par");
}
if(n4 > 0 && n4%2==0){
alert("O número: " + n4 + " é positivo e par");
}
if(n4 > 0 && n4%2!=0){
alert("O número: " + n4 + " é positivo e ímpar");
}
if(n4 < 0 && n4%2==0){
alert("O número: " + n4 + " é negativo e par");
}
if(n4 < 0 && n4%2!=0){
alert("O número: " + n4 + " é negativo e ímpar");
}
if(n4==0){
alert("O número: " + n4 + " é par");
}
if(n5 > 0 && n5%2==0){
alert("O número: " + n5 + " é positivo e par");
}
if(n5 > 0 && n5%2!=0){
alert("O número: " + n5 + " é positivo e ímpar");
}
if(n5 < 0 && n5%2==0){
alert("O número: " + n5 + " é negativo e par");
}
if(n5 < 0 && n5%2!=0){
alert("O número: " + n5 + " é negativo e ímpar");
}
if(n5==0){
alert("O número: " + n5 + " é par");
}

//Exercício 3//

var a1,a2,a3;
a1=parseInt(prompt("Digite o número de pessoas que trabalham no primeiro andar"));
a2=parseInt(prompt("Digite o número de pessoas que trabalham no segundo andar"));
a3=parseInt(prompt("Digite o número de pessoas que trabaçham no terceiro andar"));
soma1=a1+a3;
soma2=a1+a2+a3+soma1;
subtracao=soma2-a2;
alert("Os funcionários gastarão cerca de " + subtracao + " minutos para ir até a máquina");

