/*LÓGICA DE PROGRAMAÇÃO - TRABALHO
EXERCÍCIO NÚMERO: UM*/
var x, y;
var x = Number (prompt ("Digite a coordenada X do plano cartesiano."));
var y = Number (prompt ("Digite a coordenada Y do plano cartesiano."));
if (x < 0 & y < 0) {
alert ("O ponto pertence ao terceiro quadrante, no canto inferior esquerdo.")
} if (x < 0 & y === 0) {
alert ("O ponto pertence encima do eixo x, no lado esquerdo, entre o segundo e terceiro quadrante.")
} if (x < 0 & y > 0) {
alert ("O ponto pertence no segundo quadrante, no canto superior esquerdo.")
} if (x === 0 & y < 0) {
alert ("O ponto pertence encima do eixo y, no meio, entre o terceiro e o quarto quadrante.")
} if (x > 0 & y < 0) {
alert ("O ponto pertence no quarto quadrante, no canto inferior direito.")
} if (x === 0 & y > 0) {
alert ("O ponto pertence encima do eixo y, no meio, entre o primeiro e o segundo quadrante.")
} if (x > 0 & y > 0) {
alert ("O ponto pertence no primeiro quadrante, no canto superior direito.")
} if (x > 0 & y === 0) {
alert ("O ponto pertence encima do eixo x, no lado direito, entre o primeiro e o quarto quadrante.")
} if (x === 0 & y === 0) {
alert ("O ponto está na origem, no meio.")
};
--------------------------------------------------------------------------------
//EXERCÍCIO NÚMERO: DOIS
var a, b, c, d, e, pa, im, po, ne;
var a = Number (prompt ("Digite o primeiro número."));
var b = Number (prompt ("Digite o segundo número."));
var c = Number (prompt ("Digite o terceiro número."));
var d = Number (prompt ("Digite o quarto número."));
var e = Number (prompt ("Digite o quinto número."));
var pa = 0
var im = 0
var po = 0
var ne = 0
if (a === 0) {
var pa = (Number (pa) + 1)
}
if (a < 0 & a%2 < 0) {
var im = (Number (im) + 1)
var ne = (Number (ne) + 1)
}
if (a < 0 & a%2 === -0) {
var pa = (Number (pa) + 1)
var ne = (Number (ne) + 1)
}
if (a > 0 & a%2 > 0) {
var im = (Number (im) + 1)
var po = (Number (po) + 1)
}
if (a > 0 & a%2 === 0) {
var pa = (Number (pa) + 1)
var po = (Number (po) + 1)
}
if (b === 0) {
var pa = (Number (pa) + 1)
}
if (b < 0 & b%2 < 0) {
var im = (Number (im) + 1)
var ne = (Number (ne) + 1)
}
if (b < 0 & b%2 === -0) {
var pa = (Number (pa) + 1)
var ne = (Number (ne) + 1)
}
if (b > 0 & b%2 > 0) {
var im = (Number (im) + 1)
var po = (Number (po) + 1)
}
if (b > 0 & b%2 === 0) {
var pa = (Number (pa) + 1)
var po = (Number (po) + 1)
}
if (c === 0) {
var pa = (Number (pa) + 1)
}
if (c < 0 & c%2 < 0) {
var im = (Number (im) + 1)
var ne = (Number (ne) + 1)
}
if (c < 0 & c%2 === -0) {
var pa = (Number (pa) + 1)
var ne = (Number (ne) + 1)
}
if (c > 0 & c%2 > 0) {
var im = (Number (im) + 1)
var po = (Number (po) + 1)
}
if (c > 0 & c%2 === 0) {
var pa = (Number (pa) + 1)
var po = (Number (po) + 1)
}
if (d === 0) {
var pa = (Number (pa) + 1)
}
if (d < 0 & d%2 < 0) {
var im = (Number (im) + 1)
var ne = (Number (ne) + 1)
}
if (d < 0 & d%2 === -0) {
var pa = (Number (pa) + 1)
var ne = (Number (ne) + 1)
}
if (d > 0 & d%2 > 0) {
var im = (Number (im) + 1)
var po = (Number (po) + 1)
}
if (d > 0 & d%2 === 0) {
var pa = (Number (pa) + 1)
var po = (Number (po) + 1)
}
if (e === 0) {
var pa = (Number (pa) + 1)
}
if (e < 0 & e%2 < 0) {
var im = (Number (im) + 1)
var ne = (Number (ne) + 1)
}
if (e < 0 & e%2 === -0) {
var pa = (Number (pa) + 1)
var ne = (Number (ne) + 1)
}
if (e > 0 & e%2 > 0) {
var im = (Number (im) + 1)
var po = (Number (po) + 1)
}
if (e > 0 & e%2 === 0) {
var pa = (Number (pa) + 1)
var po = (Number (po) + 1)
}
alert ("Entre os números se tem: " + pa + " números pares, " + im + " ímpares, " + po + " positivos e " + ne + " negativos.");
--------------------------------------------------------------------------------
//EXERCÍCIO NÚMERO: TRÊS
var a, b, c;
var a = Number (prompt ("Digite o número de funcionários no primeiro andar."))*2;
var b = Number (prompt ("Digite o número de funcionários no segundo andar."));
var c = Number (prompt ("Digite o número de funcionários no terceiro andar."))*2;
alert ("No melhor posicionamento possivel da maquina, os funcionários gastarão: " + (a+c) + " minutos indo e voltando da maquina de café.");
